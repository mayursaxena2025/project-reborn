import io, os, json, time, uuid, re
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import StreamingResponse
from fastapi.staticfiles import StaticFiles
import pdfplumber, docx
from anthropic import Anthropic
from pptx import Presentation
from pptx.util import Inches, Pt

app = FastAPI(title="Resume Presenter")
client = Anthropic()  # reads ANTHROPIC_API_KEY
MODEL = os.getenv("MODEL", "claude-sonnet-5")
MAX_BYTES, MAX_CHARS, TTL = 5 * 1024 * 1024, 20000, 24 * 3600
DECKS: dict = {}  # id -> (expires_at, deck). Resume files are never written to disk.

SYSTEM = """You turn a resume into a presentation storyboard. Return ONLY JSON, no markdown.
Rules: use ONLY facts in the resume. Never invent employers, dates, numbers or skills.
If a number is not in the resume, do not create one. Skill levels (0-100) are rough estimates from evidence.
Schema:
{"name":str,"gender":"F"|"M"|"N" (best guess from name/pronouns; N if unclear),
 "slides":[{"t":"title","h":str,"s":str,"n":str},
  {"t":"timeline","h":str,"items":[[role,"company · dates"],...],"n":str},
  {"t":"skills","h":str,"items":[[skill,0-100],...],"n":str},
  {"t":"stats","h":str,"items":[[value,label],...],"n":str},   // only real figures from the resume; omit slide if none
  {"t":"list","h":str,"items":[[title,detail],...],"n":str},   // education/certs/projects
  {"t":"title","h":str,"s":str,"n":str}]}                       // closing
"n" is a friendly 20-40 second spoken script, third person, presented TO an audience.
Use tokens {name} {she} {her} {Her} instead of pronouns (e.g. "{Her} journey began...").
6-8 slides, max 4-5 items per slide, short on-slide text."""

def parse(name: str, data: bytes) -> str:
    n = name.lower()
    if n.endswith(".pdf"):
        with pdfplumber.open(io.BytesIO(data)) as pdf:
            return "\n".join((p.extract_text() or "") for p in pdf.pages)
    if n.endswith(".docx"):
        d = docx.Document(io.BytesIO(data))
        parts = [p.text for p in d.paragraphs]
        for t in d.tables:
            for r in t.rows:
                parts.append(" | ".join(c.text for c in r.cells))
        return "\n".join(parts)
    raise HTTPException(400, "Upload a PDF or DOCX file")

def storyboard(text: str) -> dict:
    msg = client.messages.create(model=MODEL, max_tokens=4000, system=SYSTEM,
                                 messages=[{"role": "user", "content": f"RESUME:\n{text[:MAX_CHARS]}"}])
    raw = "".join(b.text for b in msg.content if b.type == "text")
    m = re.search(r"\{.*\}", raw, re.S)
    if not m:
        raise HTTPException(502, "Could not build storyboard")
    return json.loads(m.group(0))

@app.post("/api/upload")
async def upload(file: UploadFile = File(...)):
    data = await file.read()
    if len(data) > MAX_BYTES:
        raise HTTPException(413, "File too large (max 5 MB)")
    text = parse(file.filename or "", data).strip()
    if len(text) < 100:
        raise HTTPException(422, "Could not read text from this file (scanned image PDFs are not supported yet)")
    try:
        deck = storyboard(text)
    except json.JSONDecodeError:
        raise HTTPException(502, "Storyboard generation failed, please retry")
    now = time.time()
    for k in [k for k, (e, _) in DECKS.items() if e < now]:
        DECKS.pop(k, None)
    did = uuid.uuid4().hex
    DECKS[did] = (now + TTL, deck)
    return {"id": did, "deck": deck}

@app.get("/api/deck/{did}")
def get_deck(did: str):
    if did not in DECKS: raise HTTPException(404, "Deck expired or not found")
    return DECKS[did][1]

PRON = {"F": ("she", "her", "She"), "M": ("he", "his", "He"), "N": ("they", "their", "They")}
def fill(s, deck, g):
    a, b, c = PRON.get(g, PRON["N"])
    return s.replace("{name}", deck.get("name", "")).replace("{she}", a).replace("{her}", b).replace("{Her}", c)

@app.get("/api/deck/{did}/pptx")
def export(did: str, g: str = "N"):
    if did not in DECKS: raise HTTPException(404, "Deck expired or not found")
    deck = DECKS[did][1]
    prs = Presentation(); prs.slide_width, prs.slide_height = Inches(13.33), Inches(7.5)
    for s in deck["slides"]:
        sl = prs.slides.add_slide(prs.slide_layouts[6])
        tb = sl.shapes.add_textbox(Inches(.8), Inches(.6), Inches(11.7), Inches(1.2)).text_frame
        tb.text = fill(s["h"], deck, g); tb.paragraphs[0].font.size = Pt(40); tb.paragraphs[0].font.bold = True
        body = sl.shapes.add_textbox(Inches(.8), Inches(2), Inches(11.7), Inches(4.8)).text_frame
        body.word_wrap = True
        lines = [fill(s.get("s", ""), deck, g)] if s["t"] == "title" else [
            f"{a}  —  {b}{'%' if s['t']=='skills' else ''}" for a, b in s.get("items", [])]
        for k, ln in enumerate(lines):
            p = body.paragraphs[0] if k == 0 else body.add_paragraph()
            p.text = ln; p.font.size = Pt(24); p.space_after = Pt(12)
        sl.notes_slide.notes_text_frame.text = fill(s.get("n", ""), deck, g)
    buf = io.BytesIO(); prs.save(buf); buf.seek(0)
    return StreamingResponse(buf, media_type="application/vnd.openxmlformats-officedocument.presentationml.presentation",
                             headers={"Content-Disposition": 'attachment; filename="resume-presentation.pptx"'})

app.mount("/", StaticFiles(directory="static", html=True), name="static")
