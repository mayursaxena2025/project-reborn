# Resume Presenter (sassybyte.site product)

Upload PDF/DOCX -> Claude builds a storyboard -> avatar presents slides in the browser -> PPTX export.

## Run locally
    python -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt
    export ANTHROPIC_API_KEY=sk-ant-...
    uvicorn main:app --reload      # http://localhost:8000

## Deploy (Docker)
    docker build -t resume-presenter .
    docker run -d --restart unless-stopped -p 127.0.0.1:8000:8000 --env-file .env resume-presenter

## Add as a tab on sassybyte.site
Option A - subpath (recommended), nginx inside your existing server block:

    location /resume-presenter/ {
        proxy_pass http://127.0.0.1:8000/;
        proxy_read_timeout 120s;
        client_max_body_size 6m;
    }
Then add a nav link to `/resume-presenter/` in your portfolio site.

Option B - subdomain: point `resume.sassybyte.site` at the same proxy with `location / { proxy_pass ... }` and add the DNS A/CNAME record.

The frontend uses relative URLs, so both options work with no code changes. Use HTTPS (certbot).

## Notes
- Decks live in memory for 24h with 1 worker. For multiple workers or restarts, move DECKS to Redis/SQLite.
- Add rate limiting (e.g. nginx `limit_req`) - each upload costs one Claude call.
- Not yet built: storyboard editing screen, scanned-PDF OCR, server-side TTS/MP4 export.
