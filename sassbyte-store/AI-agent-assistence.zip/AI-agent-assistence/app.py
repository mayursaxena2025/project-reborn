from __future__ import annotations

import json
import os
import re
import sqlite3
import urllib.error
import urllib.request
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, unquote, urlsplit


ROOT = Path(__file__).resolve().parent
STATIC = ROOT / "static"
DB_PATH = Path(os.environ.get("CRM_AGENT_DB", ROOT / "data" / "crm-agent.sqlite3"))
DEFAULTS = {
    "crm_leads_url": "",
    "crm_token": "",
    "sms_webhook_url": "",
    "voice_webhook_url": "",
    "calendar_webhook_url": "",
    "ollama_url": "http://localhost:11434",
    "ollama_model": "qwen2.5:3b",
    "webhook_key": "",
    "auto_followup_enabled": "false",
}
STAGES = {"new", "qualified", "nurture", "appointment", "under_contract", "closed", "disqualified"}
SETTINGS_KEYS = set(DEFAULTS)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def connect(path: Path = DB_PATH) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(path)
    connection.row_factory = sqlite3.Row
    return connection


def initialize_db(path: Path = DB_PATH) -> None:
    with connect(path) as db:
        db.executescript(
            """
            CREATE TABLE IF NOT EXISTS leads (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                phone TEXT NOT NULL DEFAULT '',
                email TEXT NOT NULL DEFAULT '',
                source TEXT NOT NULL DEFAULT 'Manual',
                timeline TEXT NOT NULL DEFAULT '',
                budget TEXT NOT NULL DEFAULT '',
                notes TEXT NOT NULL DEFAULT '',
                consent_sms INTEGER NOT NULL DEFAULT 0,
                consent_call INTEGER NOT NULL DEFAULT 0,
                stage TEXT NOT NULL DEFAULT 'new',
                score INTEGER,
                qualification TEXT NOT NULL DEFAULT '',
                crm_ref TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS appointments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                lead_id INTEGER NOT NULL REFERENCES leads(id),
                starts_at TEXT NOT NULL,
                kind TEXT NOT NULL DEFAULT 'Consultation',
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS activities (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                lead_id INTEGER,
                kind TEXT NOT NULL,
                detail TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            """
        )
        db.executemany(
            "INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)",
            DEFAULTS.items(),
        )


def record_activity(db: sqlite3.Connection, kind: str, detail: str, lead_id: int | None = None) -> None:
    db.execute(
        "INSERT INTO activities (lead_id, kind, detail, created_at) VALUES (?, ?, ?, ?)",
        (lead_id, kind, detail, utc_now()),
    )


def get_settings(db: sqlite3.Connection) -> dict[str, str]:
    values = dict(DEFAULTS)
    values.update({row["key"]: row["value"] for row in db.execute("SELECT key, value FROM settings")})
    return values


def public_settings(settings: dict[str, str]) -> dict[str, Any]:
    return {
        "crm_leads_url": settings["crm_leads_url"],
        "sms_webhook_url": settings["sms_webhook_url"],
        "voice_webhook_url": settings["voice_webhook_url"],
        "calendar_webhook_url": settings["calendar_webhook_url"],
        "ollama_url": settings["ollama_url"],
        "ollama_model": settings["ollama_model"],
        "auto_followup_enabled": settings["auto_followup_enabled"] == "true",
        "crm_token_configured": bool(settings["crm_token"]),
        "webhook_key_configured": bool(settings["webhook_key"]),
    }


def create_lead(db: sqlite3.Connection, data: dict[str, Any]) -> dict[str, Any]:
    name = str(data.get("name", "")).strip()
    phone = str(data.get("phone", "")).strip()
    email = str(data.get("email", "")).strip()
    if not name or not (phone or email):
        raise ValueError("A name and at least one contact method are required.")
    if email and not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
        raise ValueError("Enter a valid email address.")
    cursor = db.execute(
        """INSERT INTO leads
           (name, phone, email, source, timeline, budget, notes, consent_sms, consent_call, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            name,
            phone,
            email,
            str(data.get("source", "Manual")).strip() or "Manual",
            str(data.get("timeline", "")).strip(),
            str(data.get("budget", "")).strip(),
            str(data.get("notes", "")).strip(),
            int(data.get("consent_sms") is True),
            int(data.get("consent_call") is True),
            utc_now(),
        ),
    )
    lead_id = int(cursor.lastrowid)
    record_activity(db, "lead", f"New lead captured from {data.get('source', 'Manual')}.", lead_id)
    db.commit()
    return dict(db.execute("SELECT * FROM leads WHERE id = ?", (lead_id,)).fetchone())


def local_qualification(lead: dict[str, Any]) -> dict[str, Any]:
    score = 30
    if lead.get("phone"):
        score += 10
    if lead.get("email"):
        score += 10
    if lead.get("timeline"):
        score += 15
    if lead.get("budget"):
        score += 15
    if len(lead.get("notes", "")) >= 30:
        score += 10
    score = min(score, 100)
    signal = "High intent" if score >= 65 else "Needs more information"
    next_step = "Offer a consultation" if score >= 65 else "Ask about timeline and goals"
    return {
        "score": score,
        "summary": signal,
        "rationale": "Local rules-based estimate; connect Ollama for model-assisted qualification.",
        "next_step": next_step,
        "provider": "rules",
    }


def ollama_chat(settings: dict[str, str], messages: list[dict[str, str]], json_mode: bool = False) -> str:
    endpoint = settings["ollama_url"].rstrip("/") + "/api/chat"
    payload: dict[str, Any] = {
        "model": settings["ollama_model"],
        "messages": messages,
        "stream": False,
    }
    if json_mode:
        payload["format"] = "json"
    request = urllib.request.Request(
        endpoint,
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=20) as response:
        result = json.loads(response.read())
    return str(result["message"]["content"])


def qualify_lead(lead: dict[str, Any], settings: dict[str, str]) -> dict[str, Any]:
    context = json.dumps({key: lead.get(key, "") for key in ("name", "source", "timeline", "budget", "notes")})
    try:
        content = ollama_chat(
            settings,
            [
                {
                    "role": "system",
                    "content": (
                        "Qualify a real-estate sales lead. Return JSON only with integer score 0-100, "
                        "brief summary, rationale, and one next_step. Do not infer facts not supplied."
                    ),
                },
                {"role": "user", "content": context},
            ],
            json_mode=True,
        )
        result = json.loads(content)
        result["score"] = max(0, min(100, int(result["score"])))
        result["provider"] = "ollama"
        return result
    except (OSError, TimeoutError, ValueError, KeyError, json.JSONDecodeError, urllib.error.URLError):
        return local_qualification(lead)


def post_json(url: str, payload: dict[str, Any], token: str = "") -> tuple[bool, str]:
    if not url:
        return False, "No endpoint configured."
    request = urllib.request.Request(
        url,
        data=json.dumps(payload).encode(),
        headers={
            "Content-Type": "application/json",
            **({"Authorization": f"Bearer {token}"} if token else {}),
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=12) as response:
            return 200 <= response.status < 300, f"HTTP {response.status}"
    except (OSError, TimeoutError, urllib.error.URLError) as error:
        return False, str(error)


def lead_payload(lead: dict[str, Any]) -> dict[str, Any]:
    return {key: lead[key] for key in (
        "id", "name", "phone", "email", "source", "timeline", "budget", "notes",
        "consent_sms", "consent_call", "stage", "score", "qualification", "created_at",
    )}


class Handler(BaseHTTPRequestHandler):
    server_version = "OpenLeadAgent/0.1"

    def log_message(self, format_string: str, *args: Any) -> None:
        print(f"[{self.log_date_time_string()}] {format_string % args}")

    def send_json(self, payload: Any, status: int = 200) -> None:
        body = json.dumps(payload).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def read_json(self) -> dict[str, Any]:
        size = int(self.headers.get("Content-Length", "0"))
        if size > 1_000_000:
            raise ValueError("Request body is too large.")
        payload = json.loads(self.rfile.read(size) or b"{}")
        if not isinstance(payload, dict):
            raise ValueError("Expected a JSON object.")
        return payload

    def do_GET(self) -> None:
        route = urlsplit(self.path)
        if route.path == "/" or route.path == "/index.html":
            return self.send_file("index.html", "text/html; charset=utf-8")
        if route.path in ("/app.css", "/app.js"):
            return self.send_file(route.path.lstrip("/"), "text/css; charset=utf-8" if route.path.endswith("css") else "text/javascript; charset=utf-8")
        if not route.path.startswith("/api/"):
            return self.send_json({"error": "Not found"}, 404)
        initialize_db()
        with connect() as db:
            if route.path == "/api/dashboard":
                counts = {row["stage"]: row["amount"] for row in db.execute("SELECT stage, COUNT(*) amount FROM leads GROUP BY stage")}
                lead_count = db.execute("SELECT COUNT(*) FROM leads").fetchone()[0]
                appointments = db.execute(
                    "SELECT a.*, l.name lead_name FROM appointments a JOIN leads l ON l.id = a.lead_id ORDER BY starts_at LIMIT 6"
                ).fetchall()
                return self.send_json({"counts": counts, "lead_count": lead_count, "appointments": [dict(row) for row in appointments]})
            if route.path == "/api/leads":
                query = parse_qs(route.query).get("q", [""])[0].strip()
                if query:
                    rows = db.execute(
                        """SELECT * FROM leads WHERE name LIKE ? OR phone LIKE ? OR email LIKE ?
                           ORDER BY created_at DESC LIMIT 100""",
                        (f"%{query}%", f"%{query}%", f"%{query}%"),
                    ).fetchall()
                else:
                    rows = db.execute("SELECT * FROM leads ORDER BY created_at DESC LIMIT 100").fetchall()
                return self.send_json([dict(row) for row in rows])
            if route.path == "/api/activities":
                rows = db.execute(
                    """SELECT a.*, l.name lead_name FROM activities a LEFT JOIN leads l ON l.id = a.lead_id
                       ORDER BY a.id DESC LIMIT 30"""
                ).fetchall()
                return self.send_json([dict(row) for row in rows])
            if route.path == "/api/settings":
                return self.send_json(public_settings(get_settings(db)))
            match = re.fullmatch(r"/api/leads/(\d+)", route.path)
            if match:
                lead = db.execute("SELECT * FROM leads WHERE id = ?", (int(match.group(1)),)).fetchone()
                return self.send_json(dict(lead) if lead else {"error": "Lead not found"}, 200 if lead else 404)
        return self.send_json({"error": "Not found"}, 404)

    def do_POST(self) -> None:
        initialize_db()
        try:
            payload = self.read_json()
            with connect() as db:
                settings = get_settings(db)
                if self.path in ("/api/leads", "/api/webhooks/intake"):
                    if self.path == "/api/webhooks/intake" and settings["webhook_key"]:
                        if self.headers.get("X-Agent-Key") != settings["webhook_key"]:
                            return self.send_json({"error": "Unauthorized"}, 401)
                    lead = create_lead(db, payload)
                    sync_ok, sync_detail = True, "CRM sync not configured."
                    if settings["crm_leads_url"]:
                        sync_ok, sync_detail = post_json(
                            settings["crm_leads_url"], lead_payload(lead), settings["crm_token"]
                        )
                        if sync_ok:
                            record_activity(db, "crm", "Lead sent to connected CRM.", lead["id"])
                        else:
                            record_activity(db, "warning", f"CRM sync failed: {sync_detail}", lead["id"])
                        db.commit()
                    return self.send_json({"lead": lead, "crm_sync": sync_detail}, 201)
                if self.path == "/api/settings":
                    for key, value in payload.items():
                        if key in SETTINGS_KEYS:
                            db.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, str(value).lower() if isinstance(value, bool) else str(value).strip()))
                    db.commit()
                    return self.send_json(public_settings(get_settings(db)))
                if self.path == "/api/agent/chat":
                    message = str(payload.get("message", "")).strip()
                    if not message:
                        raise ValueError("Enter a question for the assistant.")
                    leads = [dict(row) for row in db.execute(
                        "SELECT name, source, timeline, budget, stage, score FROM leads ORDER BY created_at DESC LIMIT 30"
                    )]
                    try:
                        answer = ollama_chat(settings, [
                            {"role": "system", "content": "You are an operations assistant for a real-estate lead acquisition team. Use only the provided CRM snapshot, clearly say when data is missing, and never claim to perform actions."},
                            {"role": "user", "content": f"CRM snapshot: {json.dumps(leads)}\n\nQuestion: {message}"},
                        ])
                        return self.send_json({"answer": answer, "provider": "ollama"})
                    except (OSError, TimeoutError, urllib.error.URLError) as error:
                        return self.send_json({"error": f"Local AI is unavailable. Check Ollama settings. ({error})"}, 503)
                match = re.fullmatch(r"/api/leads/(\d+)/qualify", self.path)
                if match:
                    lead_id = int(match.group(1))
                    row = db.execute("SELECT * FROM leads WHERE id = ?", (lead_id,)).fetchone()
                    if not row:
                        return self.send_json({"error": "Lead not found"}, 404)
                    result = qualify_lead(dict(row), settings)
                    stage = "qualified" if result["score"] >= 65 else "nurture"
                    qualification = json.dumps(result)
                    db.execute("UPDATE leads SET score = ?, qualification = ?, stage = ? WHERE id = ?", (result["score"], qualification, stage, lead_id))
                    record_activity(db, "qualification", f"Qualified at {result['score']} points; moved to {stage}.", lead_id)
                    followup_sent = False
                    if stage == "qualified" and row["consent_sms"] and settings["auto_followup_enabled"] == "true" and settings["sms_webhook_url"]:
                        ok, detail = post_json(settings["sms_webhook_url"], {
                            "event": "lead.qualified", "channel": "sms", "lead": lead_payload(dict(row)),
                            "message": f"Hi {row['name']}, thanks for reaching out. When is a good time to talk about your goals?",
                        })
                        followup_sent = ok
                        record_activity(db, "sms" if ok else "warning", "Automated qualification follow-up sent." if ok else f"Follow-up failed: {detail}", lead_id)
                    db.commit()
                    return self.send_json({"lead": dict(db.execute("SELECT * FROM leads WHERE id = ?", (lead_id,)).fetchone()), "qualification": result, "followup_sent": followup_sent})
                match = re.fullmatch(r"/api/leads/(\d+)/stage", self.path)
                if match:
                    lead_id = int(match.group(1))
                    stage = str(payload.get("stage", ""))
                    if stage not in STAGES:
                        raise ValueError("Choose a valid pipeline stage.")
                    lead = db.execute("SELECT name FROM leads WHERE id = ?", (lead_id,)).fetchone()
                    if not lead:
                        return self.send_json({"error": "Lead not found"}, 404)
                    db.execute("UPDATE leads SET stage = ? WHERE id = ?", (stage, lead_id))
                    record_activity(db, "stage", f"{lead['name']} moved to {stage.replace('_', ' ')}.", lead_id)
                    db.commit()
                    return self.send_json({"ok": True, "stage": stage})
                match = re.fullmatch(r"/api/leads/(\d+)/(sms|call)", self.path)
                if match:
                    lead_id, channel = int(match.group(1)), match.group(2)
                    lead_row = db.execute("SELECT * FROM leads WHERE id = ?", (lead_id,)).fetchone()
                    if not lead_row:
                        return self.send_json({"error": "Lead not found"}, 404)
                    lead = dict(lead_row)
                    consent_field = "consent_sms" if channel == "sms" else "consent_call"
                    endpoint_field = "sms_webhook_url" if channel == "sms" else "voice_webhook_url"
                    if not lead[consent_field]:
                        return self.send_json({"error": f"Recorded {channel.upper()} consent is required."}, 409)
                    if not settings[endpoint_field]:
                        return self.send_json({"error": f"Configure a {channel.upper()} webhook before sending."}, 409)
                    message = str(payload.get("message", "")).strip()
                    if channel == "sms" and not message:
                        raise ValueError("Enter a text message.")
                    ok, detail = post_json(settings[endpoint_field], {
                        "event": f"lead.outbound_{channel}", "channel": channel,
                        "lead": lead_payload(lead), "message": message,
                    })
                    record_activity(db, channel if ok else "warning", f"Outbound {channel.upper()} accepted by webhook." if ok else f"Outbound {channel.upper()} failed: {detail}", lead_id)
                    db.commit()
                    return self.send_json({"ok": ok, "detail": detail}, 200 if ok else 502)
                if self.path == "/api/appointments":
                    lead_id = int(payload.get("lead_id", 0))
                    starts_at = str(payload.get("starts_at", "")).strip()
                    lead = db.execute("SELECT * FROM leads WHERE id = ?", (lead_id,)).fetchone()
                    if not lead:
                        return self.send_json({"error": "Choose an existing lead."}, 404)
                    try:
                        datetime.fromisoformat(starts_at)
                    except ValueError as error:
                        raise ValueError("Enter a valid appointment date and time.") from error
                    cursor = db.execute(
                        "INSERT INTO appointments (lead_id, starts_at, kind, created_at) VALUES (?, ?, ?, ?)",
                        (lead_id, starts_at, str(payload.get("kind", "Consultation")), utc_now()),
                    )
                    db.execute("UPDATE leads SET stage = 'appointment' WHERE id = ?", (lead_id,))
                    record_activity(db, "appointment", f"{payload.get('kind', 'Consultation')} scheduled for {starts_at}.", lead_id)
                    db.commit()
                    if settings["calendar_webhook_url"]:
                        ok, detail = post_json(settings["calendar_webhook_url"], {
                            "event": "appointment.created", "appointment_id": cursor.lastrowid,
                            "starts_at": starts_at, "kind": payload.get("kind", "Consultation"),
                            "lead": lead_payload(dict(lead)),
                        })
                        if not ok:
                            record_activity(db, "warning", f"Calendar sync failed: {detail}", lead_id)
                            db.commit()
                    return self.send_json({"ok": True, "id": cursor.lastrowid}, 201)
        except (ValueError, json.JSONDecodeError) as error:
            return self.send_json({"error": str(error)}, 400)
        except (sqlite3.Error, KeyError) as error:
            return self.send_json({"error": str(error)}, 500)
        return self.send_json({"error": "Not found"}, 404)

    def send_file(self, name: str, content_type: str) -> None:
        path = (STATIC / name).resolve()
        if path.parent != STATIC.resolve() or not path.is_file():
            return self.send_json({"error": "Not found"}, 404)
        body = path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


if __name__ == "__main__":
    initialize_db()
    host = os.environ.get("HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", "8000"))
    print(f"Open Lead Agent running at http://{host}:{port}")
    ThreadingHTTPServer((host, port), Handler).serve_forever()