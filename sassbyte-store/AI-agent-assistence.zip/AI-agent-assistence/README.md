# OpenLead

An open-source, local-first acquisition desk for lead intake, qualification, CRM sync, SMS/voice workflow hooks, and appointment scheduling. The starter runs with Python's standard library and SQLite; it does not require a paid model or SaaS account.

## Run locally

Requirements: Python 3.11 or newer.

```sh
python3 app.py
```

Open <http://127.0.0.1:8000>. Data is stored in `data/crm-agent.sqlite3`. Set `CRM_AGENT_DB` to move the SQLite file, or `HOST` and `PORT` to change the listener. The default listener is loopback-only.

Run the backend tests with:

```sh
python3 -m unittest -v
```

## AI

Install [Ollama](https://ollama.com), then pull an open model, for example:

```sh
ollama pull qwen2.5:3b
```

The default model URL and name are prefilled under Connections. Lead qualification uses Ollama when available and falls back to transparent local scoring rules. The assistant chat requires Ollama and answers from a bounded CRM snapshot; it does not execute CRM actions.

## Integrations

- **CRM:** Configure a JSON `POST` lead-create endpoint and optional bearer token. New leads are sent to this endpoint. Every CRM has a different schema and auth model; use the CRM's API directly when compatible or bridge it with a self-hosted tool such as n8n. The UI and backend expose one adapter contract; CRM-specific field mapping is not universal.
- **SMS:** Configure an SMS webhook that accepts `{event, channel, lead, message}`. The app requires recorded lead consent before dispatch. Connect a self-hosted provider/bridge such as an n8n workflow and an SMS gateway you control. This app does not include a carrier or send a text by itself.
- **Voice:** Configure a voice webhook. Explicit operator actions can dispatch call requests only where call consent is recorded. A separate voice stack (for example, Asterisk plus a voice agent) must handle telephony and return webhooks for call outcomes.
- **Appointments:** Scheduling is recorded locally and can emit an `appointment.created` event to a calendar or automation webhook.
- **Inbound intake:** `POST /api/webhooks/intake` accepts a lead JSON object. Set an inbound webhook key in Connections to require the `X-Agent-Key` header.

Webhook payloads use JSON. Test integrations with a non-production endpoint before connecting live customer data. Never expose this unauthenticated local UI directly to the public internet; use a secured reverse proxy, access control, TLS, and appropriate retention/consent policies before a production deployment. Secrets are stored in the local SQLite database in this starter and should be protected with OS-level file permissions.

## Current MVP boundary

This is an extensible single-operator starter, not a production multi-tenant CRM or a universal drop-in connector. It provides a generic REST/webhook boundary because open-source CRM APIs vary. It does not include inbound telephony, carrier delivery, calendar availability checks, OAuth flows, CRM-specific adapters, team auth, or a workflow scheduler. Those require selecting target systems and credentials before implementation.