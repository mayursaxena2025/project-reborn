import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import app


class LeadWorkflowTests(unittest.TestCase):
    def setUp(self):
        self.tempdir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.tempdir.name) / "test.sqlite3"
        app.initialize_db(self.db_path)

    def tearDown(self):
        self.tempdir.cleanup()

    def test_create_lead_requires_name_and_contact(self):
        with app.connect(self.db_path) as db:
            with self.assertRaisesRegex(ValueError, "contact method"):
                app.create_lead(db, {"name": "No Contact"})

    def test_create_lead_records_explicit_consent(self):
        with app.connect(self.db_path) as db:
            lead = app.create_lead(db, {
                "name": "Jordan Lee", "phone": "555-0100", "consent_sms": True,
            })
        self.assertEqual(lead["stage"], "new")
        self.assertEqual(lead["consent_sms"], 1)
        self.assertEqual(lead["consent_call"], 0)

    def test_string_false_does_not_grant_consent(self):
        with app.connect(self.db_path) as db:
            lead = app.create_lead(db, {
                "name": "Jordan Lee", "phone": "555-0100", "consent_sms": "false",
            })
        self.assertEqual(lead["consent_sms"], 0)

    def test_qualification_uses_rules_when_ollama_is_unavailable(self):
        lead = {"name": "Jordan", "phone": "555", "email": "j@example.com", "timeline": "30 days", "budget": "$200k", "notes": "Looking to sell a property soon."}
        with patch.object(app, "ollama_chat", side_effect=OSError("offline")):
            result = app.qualify_lead(lead, dict(app.DEFAULTS))
        self.assertEqual(result["provider"], "rules")
        self.assertEqual(result["score"], 90)

    def test_public_settings_never_exposes_secrets(self):
        settings = dict(app.DEFAULTS, crm_token="secret", webhook_key="another-secret")
        public = app.public_settings(settings)
        self.assertNotIn("crm_token", public)
        self.assertNotIn("webhook_key", public)
        self.assertTrue(public["crm_token_configured"])
        self.assertTrue(public["webhook_key_configured"])

    def test_stage_allowlist_excludes_arbitrary_values(self):
        self.assertIn("qualified", app.STAGES)
        self.assertNotIn("drop_database", app.STAGES)


if __name__ == "__main__":
    unittest.main()